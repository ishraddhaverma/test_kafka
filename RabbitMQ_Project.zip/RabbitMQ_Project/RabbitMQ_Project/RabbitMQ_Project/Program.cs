﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using RabbitMQ.Client;

namespace RabbitMQ_Project
{
    class Program
    {
        static void Main(string[] args)
        {

            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: "Test_Exchange", type: "direct", durable : true);
                var rountingKey = "12345";
                var body = Encoding.UTF8.GetBytes("Hello Shraddha");


                while (true)
                {
                    channel.BasicPublish(exchange: "Test_Exchange",
                        routingKey: rountingKey,
                        basicProperties: null,
                        body:body
                        );
                    Console.WriteLine("[x] Sent '{0}':Hello Shraddha",rountingKey);
                    Thread.Sleep(1000);

                }

            }
        }
    }
}
